export default function CheckoutMessage() {
  return (
    <main>
      <div className="checkoutmessage">
        <h1>Checkout</h1>
        <p>Please review the items you are buying.</p>
      </div>
    </main>
  );
}
