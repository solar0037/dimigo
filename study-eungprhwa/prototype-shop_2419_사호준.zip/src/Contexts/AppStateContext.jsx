import React from "react";

const AppStateContext = React.createContext();

export default AppStateContext;
